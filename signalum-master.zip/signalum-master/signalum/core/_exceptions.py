""" Project based Exceptions """


class InterfaceError(Exception):
    pass

class AdapterUnaccessibleError(Exception):
    pass
